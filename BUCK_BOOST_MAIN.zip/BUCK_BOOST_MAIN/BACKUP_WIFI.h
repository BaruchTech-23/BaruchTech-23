#ifndef WIFI_h
#define WIFI_h
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <SPIFFS.h>
#include <ESPmDNS.h>
#include "HTML.h"

AsyncWebServer server(80);  // Object of WebServer(HTTP port, 80 is defult)

class Files {
  public:
    void WriteFile(String text) { /////Function
      File file = SPIFFS.open("/password.txt", "w");
      file.println(text);
      file.close();
    }

    String ReadFile() { //////// Another Function
      File file = SPIFFS.open("/password.txt", "r");
      String Data = "";
      while (file.available()) {
        Data += char(file.read());
      }
      file.close();
      Data.trim();
      return Data;
    }
};

class WIFI : public Files {
  private:

    bool auth_flag = false;
    unsigned long previousMillis = 0;

  public:

    void WIFI_initialise(String ssid_name) {
      if (!SPIFFS.begin()) {
        Serial.println("An Error has occurred while mounting SPIFFS");
        return;
      }

      //const char* ssid = "DCDCUMX12V30A";
      const char* ssid = ssid_name.c_str();
      String passwordStr = ReadFile();
      const char* password = passwordStr.c_str();
      WiFi.softAP(ssid, password);
      if (!MDNS.begin("dcdccharger")) {
        Serial.println("Error");
        return;
      }
      IPAddress IP = WiFi.softAPIP();
    }

    void Routing() {

      server.on("/", HTTP_GET, [](AsyncWebServerRequest * request) {
        request ->send(200, "text/html", LoginHTML); //////////////////////// FOR LOGIN PAGE
      });


      server.on("/pd", HTTP_POST, [this](AsyncWebServerRequest * request) {
        if (request->hasParam("pd_code", true)) {
          String product_code = request->getParam("pd_code", true)->value();

          if (product_code == "01" | product_code == "1") {
            this->auth_flag = true;
            request ->send(200, "text/html", "<script>window.location.href='/main';</script>");
          }
          else {
            request->send(400, "text/plain", "Product Code Wrong"); // Product Code Wrong Page
          }

        } else {
          request->send(400, "text/plain", "Missing parameter");
        }
      });

      server.on("/main", HTTP_GET, [this](AsyncWebServerRequest * request) {
        if (this->auth_flag == true) {
          request->send(200, "text/html", mainHTML);                         ///////FOR MAIN MONITORING PAGE
        }
        else {
          request->send(403, "text/plain", "Access Forbidden. Need Product Code"); //// Authetication Error Page
        }

      });

      server.on("/um", HTTP_GET, [](AsyncWebServerRequest * request) {
        request->send(SPIFFS, "/um.png", "image/png");
      });

      /*server.on("/cc", HTTP_GET, [](AsyncWebServerRequest * request) {
        request->send(SPIFFS, "/cc.png", "image/png");
      });*/

      server.on("/text", HTTP_POST, [this](AsyncWebServerRequest * request) { ////// Password Change Handle
        if (request->hasParam("input_text", true)) {
          String newPassword = request->getParam("input_text", true)->value();
          this->WriteFile(newPassword);
          request->send(200, "text/plain", "New Password is getting set");
          delay(500);
          this->auth_flag = false;

        } else {
          request->send(400, "text/plain", "Missing parameter");
        }
      });


      server.begin();
    }


    void updateValues(float inputV, float outputV, float soc, float current) {
      unsigned long currentMillis = millis();
      if (currentMillis - previousMillis >= 1000) {
        ///Update HTML (MAIN)
        String newHTML = R"(
 <head>

 <style> 

 .logo{
  width: 50%;
  height: 10%;
 }
 .product {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
  height: auto;
  }

  
 .changePassword {
 width: 10%;
  margin: auto;
  padding:30px;
 }
 </style>
 </head>

 <body>
  <img src="um" class="logo">
  <img src="cc" class="product">
  <h1 style = "text-align: center"> Simple HTML For Battery Charger </h1> 
  <div id="data" class="refresh"> 
  <table border='1' style = "margin-left: auto; margin-right: auto;">
  <tr>
    <th>Parameter</th>
    <th>Value</th>
  </tr>
  <tr><td>Input Voltage</td><td>)" + String(inputV) + R"( V </td></tr>
  <tr><td>Output Voltage</td><td>)" + String(outputV) + R"( V </td></tr>
  <tr><td>Charging Current</td><td>)" + String(current) + R"( A </td></tr>
  <tr><td>SOC</td><td>)" + String(soc) + R"( % </td></tr>
  
  </table> 
  
  </div>

 <div class="changePassword">

  <form action='/text' method='post'>
  <input type='text' name='input_text' placeholder= 'New Wifi Password'>
  <input type='submit' style="margin-top: 10px; margin-left: 50px;">
  </form>
  </div>
  
  <script>
    
   setInterval(function(){
    var data = document.getElementById("data");
    data.classList.remove('refresh');
    void data.offsetWidth;
    data.classList.add('refresh');
   }, 1000);
 </script>

  </body>
  )";

        mainHTML = newHTML;
      }
    }
};


#endif
