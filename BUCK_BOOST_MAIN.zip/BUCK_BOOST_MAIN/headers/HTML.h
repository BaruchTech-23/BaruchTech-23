#ifndef HTML_h
#define HTML_h

//////////////////// Login Page ///////////////////
String LoginHTML = R"( 

<head>
<style>
 .credential {
 width: 10%;
  margin: auto;
  padding:30px;
 }
</style>
</head>
<body>

  <h1 style = "text-align: center"> Login Page </h1>
 <div class="credential">
  
  <form action='/pd' method='post'>
  <input type='text' name='pd_code' placeholder= 'Product Code'>
  <input type='submit' style="margin-top: 10px; margin-left: 50px;">
  </form>
  </div>

</body>


)";



String mainHTML = R"(<h1> Main </h1>)";



#endif 
