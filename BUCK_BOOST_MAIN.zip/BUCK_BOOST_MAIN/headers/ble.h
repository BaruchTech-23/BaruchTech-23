/*

Bluetooth LE Header for ESP32 based Ultramax Galaxy Products

Developer	: Min Thet Zan
Version				: 1.01
Compatible  devices	: ESP32
Tested devices		: ESP32-S3, ESP32-Pico-mini-02
Date     			: 8/11/2023
Revised Date		: 12/12/2023


*/


#ifndef ble_h
#define ble_h
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
#include <ArduinoJson.h>
#include <string>

using namespace std;

#define SERVICE_UUID "5883168a-d55c-4e90-ac33-d33dfc65e343"
#define Transmit_UUID "8149f2ad-2324-4210-a98d-a7739eb87b4f"
#define Receive_UUID "9f7c66a2-b6ed-4be4-a045-ec12af692e91"

int connectionCount = 0;
BLECharacteristic *pTx;  //Transmit Characteristic
BLECharacteristic *pRx;  //Receive Characteristic

class Callbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      connectionCount++;
    }

    void onDisconnect(BLEServer* pServer) {
      connectionCount--;
    }
};

void BLESetup(string name) {
  BLEDevice::init(name);
  BLEServer *pServer = BLEDevice::createServer();

  pServer->setCallbacks(new Callbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  //Create characteristics
  pTx = pService->createCharacteristic(
          Transmit_UUID,
          BLECharacteristic::PROPERTY_READ);

  pRx = pService->createCharacteristic(
          Receive_UUID,
          BLECharacteristic::PROPERTY_WRITE);

  //pTx->setValue("From Charger");
  pService->start();
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  // functions that help with iPhone connections issue
  pAdvertising->setMinPreferred(0x12);
}

void BLESend(const char* data) {
  //dtostrf((float)13.15, 7, 3, buffer);
  BLEDevice::startAdvertising();
  pTx->setValue(data);
  pTx->notify();
}

void BLEUTF8(const char* utf8Str) {
  int len = strlen(utf8Str);
  uint8_t* data = (uint8_t*) utf8Str;
  pTx->setValue(data, len);
  pTx->notify();
}

void BLEReceive() {
  BLEDevice::startAdvertising();
  string ReceivedData = pRx->getValue();
  if (!ReceivedData.empty()) {
    Serial.print(ReceivedData.c_str());
  }
  pRx->setValue("");
}

int BLE_device_count() {
  return connectionCount;
}

#endif
