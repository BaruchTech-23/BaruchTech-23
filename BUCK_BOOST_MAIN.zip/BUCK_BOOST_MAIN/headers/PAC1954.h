

#include <Arduino.h>
#include <Wire.h>
#define I2C Wire


class PAC195x {

private:
  int deviceAddress = 0x10;
  
public:
  void Write(int address, uint16_t data) {
    byte HB = (data >> 8) & 0xFF;
    byte LB = data & 0xFF;
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.write(HB);
    I2C.write(LB);
    I2C.endTransmission();
  }
  uint16_t Read(int address) {
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.endTransmission();
    I2C.requestFrom(deviceAddress, 2);
    byte first1_byte = I2C.read();
    byte second1_byte = I2C.read();
    uint16_t data = (first1_byte << 8) | (second1_byte);
    return data;
  }

  uint16_t Read16bits(int address) {  // 2Byte Data Reading
    uint8_t buf[2];
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.endTransmission();
    I2C.requestFrom(deviceAddress, 2);
    int index = 0;
    while (I2C.available() && index < 2) {
      byte data = I2C.read();
      buf[index] = data;
      index++;
    }
    int16_t B2data;
    for (int i = 0; i < 2; i++) {
      B2data |= (uint16_t)(buf[i] << (8 * (1 - i)));
    }

    return (int)B2data;
  }

  uint64_t Read56bits(int address) {  //Read 7 Bytes
    uint8_t buf[7];
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.endTransmission();
    I2C.requestFrom(deviceAddress, 7);
    int index = 0;
    while (I2C.available() && index <= 7) {
      byte data = I2C.read();
      buf[index] = data;
      index++;
    }
    delay(30);
    uint64_t B7data = 0;
    for (int i = 0; i <= 7; i++) {
      B7data |= (uint64_t)(buf[i] << (8 * (6 - i)));
    }
    return (uint16_t)(buf[0] << 8) | buf[1];
  }

  uint8_t Read8bits(int address) {  //Only 1 byte of data
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.endTransmission();
    I2C.requestFrom(deviceAddress, 1);
    return I2C.read();
  }

  void initialise(int sda = 1, int scl = 2) {
    I2C.begin(sda, scl);
  }
  
};
