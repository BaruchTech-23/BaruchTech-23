#ifndef WIFI_h
#define WIFI_h
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <SPIFFS.h>
#include <ESPmDNS.h>
#include "HTML.h"

AsyncWebServer server(80);  // Object of WebServer(HTTP port, 80 is defult)

class Files {
  public:
    void WriteFile(String text) { /////Function
      File file = SPIFFS.open("/password.txt", "w");
      file.println(text);
      file.close();
    }

    String ReadFile() { //////// Another Function
      File file = SPIFFS.open("/password.txt", "r");
      String Data = "";
      while (file.available()) {
        Data += char(file.read());
      }
      file.close();
      Data.trim();
      return Data;
    }
};

class WIFI : public Files {
  private:

    bool auth_flag = false;
    unsigned long previousMillis = 0;

  public:

    void WIFI_initialise(String ssid_name) {
      if (!SPIFFS.begin()) {
        Serial.println("An Error has occurred while mounting SPIFFS");
        return;
      }

      //const char* ssid = "DCDCUMX12V30A";
      const char* ssid = ssid_name.c_str();
      String passwordStr = ReadFile();
      const char* password = passwordStr.c_str();
      WiFi.softAP(ssid, password);
      if (!MDNS.begin("dcdccharger")) {
        Serial.println("Error");
        return;
      }
      IPAddress IP = WiFi.softAPIP();
    }

    void Routing() {

      server.on("/", HTTP_GET, [](AsyncWebServerRequest * request) {
        request ->send(200, "text/html", LoginHTML); //////////////////////// FOR LOGIN PAGE
      });


      server.on("/pd", HTTP_POST, [this](AsyncWebServerRequest * request) {
        if (request->hasParam("pd_code", true)) {
          String product_code = request->getParam("pd_code", true)->value();

          if (product_code == "1") {
            this->auth_flag = true;
            request ->send(200, "text/html", "<script>window.location.href='/main';</script>");
          }
          else {
            request->send(400, "text/plain", "Product Code Wrong"); // Product Code Wrong Page
          }

        } else {
          request->send(400, "text/plain", "Missing parameter");
        }
      });

      server.on("/main", HTTP_GET, [this](AsyncWebServerRequest * request) {
        if (this->auth_flag == true) {
          request->send(200, "text/html", mainHTML);                         ///////FOR MAIN MONITORING PAGE
        }
        else {
          request->send(403, "text/plain", "Access Forbidden. Need Product Code"); //// Authetication Error Page
        }

      });

      server.on("/chargerLogo", HTTP_GET, [](AsyncWebServerRequest * request) {
        request->send(SPIFFS, "/chargerLogo.png", "image/png");
      });

      server.on("/text", HTTP_POST, [this](AsyncWebServerRequest * request) { ////// Password Change Handle
        if (request->hasParam("input_text", true)) {
          String newPassword = request->getParam("input_text", true)->value();
          this->WriteFile(newPassword);
          request->send(200, "text/plain", "New Password is getting set");
          delay(500);
          this->auth_flag = false;

        } else {
          request->send(400, "text/plain", "Missing parameter");
        }
      });


      server.begin();
    }



    void updateValues(float inputV, float outputV, float soc, float current) {
      unsigned long currentMillis = millis();
      if (currentMillis - previousMillis >= 1000) {
        ///Update HTML (MAIN)
        String newHTML = R"(
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DC DC Charger</title>
</head>

<style>
    body {
      background-color: black;
    }
    .image {
        text-align: center;
        margin-top: 6%;
        margin-bottom: 50px;
        margin-left: 3%;
      }
    .header{
        text-align: center;
        color: white;
        font-family: Arial, Helvetica, sans-serif;
        font-size: 22px;
        margin-bottom: 34px;
        
    }
    .container {
        display: flex;
        justify-content: center;
      }
      
      .body_tab {
        width: 90%;
        background-color: #4A4B52;
        border-radius: 5px;
        padding-bottom: 20px;
        text-align: center;
      }

      .table-title{
        font-family: Arial, Helvetica, sans-serif;
        font-size: 14px;
        font-weight: bold;
        color: white;
      }

      table {
        margin: 0 auto;
        width: 90%;
        color: white;
        border-collapse: collapse;
        background-color: #414040;
        
      }
      
      td, th {
        border: 1px solid white;
        text-align: center;
        padding: 18px;
        font-family: Arial, Helvetica, sans-serif;
        
      }
      td {
        font-size: 12px;
      }
      th {
        width: 20%;
        font-size: 13px;
      }
      
      @media screen and (max-width: 60px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
      
        .rectangle {
          width: 80%;
        }
      }

      .changePassword{
        width: 30%;
        margin-left: 15%;
        font-family: Arial, Helvetica, sans-serif;
        padding:30px;
        
      }

      .textBox{
        width: 200px;
        height: 30px;
        font-family: Arial, Helvetica, sans-serif;
      
      }
      .smbt{
        margin-top: 10px; 
        margin-left: 60px;
        border: 3px white;
        border-radius: 50px;
        width: 100px;
        height: 50px;
        background-color: #35459C;
        color: white;
        font-family: Arial, Helvetica, sans-serif;
        
      }
</style>
<body>
    <div class="image">
        <img src="chargerLogo" alt="logo" width="210" height="55">
    </div>
    
    <h1 class="header"> DC DC CHARGER OFFLINE MONITORING </h1>
    <h1 class="header"> OFFLINE MONITORING </h1>

    <div class="container">
    <div class="body_tab">
        <h2 class="table-title"> STATUS </h2>
        <table>


  <tr>
    <th>PARAMETER</th>
    <th>VALUE</th>
  </tr>
  <tr><td>INPUT VOLTAGE</td><td>)" + String(inputV) + R"( V </td></tr>
  <tr><td>OUTPUT VOLTAGE</td><td>)" + String(outputV) + R"( V </td></tr>
  <tr><td>CHARGING CURRENT</td><td>)" + String(current) + R"( A </td></tr>
  <tr><td>BATTERY PERCENTAGE</td><td>)" + String(soc) + R"( % </td></tr>
  
  </table> 
  
  </div>
  </div>

    <div class="changePassword">
        <form action="/text" method="post">
          <input type="text" name="input_text" placeholder="New WiFi Password" class="textBox">
          <input type="submit" class="smbt">
        </form>
    </div>

    <script> /* For the height */
        window.onload = function() {
          var table = document.getElementById('table');
          var rectangle = document.getElementById('rectangle');
          var tableHeight = table.offsetHeight + 120;
          rectangle.style.height = tableHeight + 'px';
        };
    </script>
</body>

  )";

        mainHTML = newHTML;
      }
    }
};


#endif
