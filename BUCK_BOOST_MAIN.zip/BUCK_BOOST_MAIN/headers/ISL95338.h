/* 
  Project: Ultramax Car Battery Charger
  IC: ISL95338
  Author: Min Thet Zan (Embedded Engineer)
  Date: 29/08/2023
  Version: 1.0
  Description:
  This header file is for ISL95338 Bidirectional Buck-Boost Converter Regulator IC. 
  Datasheet can be found on https://www.renesas.com
  
 */
#ifndef ISL95338_h
#define ISL95338_h
#include "Arduino.h"
#include <Wire.h>
#define I2C Wire

//Registers
#define SystemCurrentLimit 0x14
#define ForwardRegulatingVoltage 0x15
#define Control0 0x39
#define Information1 0x3A
#define Control1 0x3C
#define Control2 0x3D
#define ForwardInputCurrent 0x3F
#define ReverseRegulatingVoltage 0x49
#define ReverseOutputCurrent 0x4A
#define InputVoltageLimit 0x4B
#define Control3 0x4C
#define Information2 0x4D
#define Control4 0x4E

//Voltages
#define V_12 0x1AC0 //12.28 V
#define V_14_8 0x2040 //14.8 V
#define V_13_5 0x1DF0 //13.5
#define V_15 0x2080 //15 V
#define V_16 0x2A40  //16.224V


//Current
#define A_4 0x1000 // 4A

#define Device 0x48  //Default I2C address

//Switching Frequency
#define F_1000k 0x00
#define F_910k 0x01
#define F_850k 0x02
#define F_787k 0x03
#define F_744k 0x04
#define F_695k 0x05
#define F_660k 0x06
#define F_620k 0x07

//Operating Mode
#define Default 0x00
#define NoUse   0x04
#define Buck    0x05
#define Boost   0x06
#define Buck_Boost 0x07

class ISL95338 {

private:
  int deviceAddress; 

public:
  void initialise(int SDA = 1, int SCL = 2, int device = Device) { //Defaults are 2 SDA, 1 SCL and 0x49 Device Address
    I2C.begin(SDA, SCL);
    deviceAddress = device; 
  }
  void Write(int address, uint16_t data) {
    byte LB = data & 0xFF;
    byte HB = (data >> 8) & 0xFF;
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.write(LB);
    I2C.write(HB);
    I2C.endTransmission();
  }
  uint16_t Read(int address) {
    I2C.beginTransmission(deviceAddress);
    I2C.write(address);
    I2C.endTransmission();
    I2C.requestFrom(deviceAddress, 2);
    byte low = I2C.read();
    byte high = I2C.read();
    uint16_t data = (high << 8) | low;
    return data;
  }

  //Only use the below methods only if the specific parameters are needed. Otherwise manually read and write to the Registers
  void setSwitchingFreq(int freq = F_1000k, int mode = 0) {  //To customise the frequency and mode
    switch (mode) {
      case 0:  //Default (Disabled Force Reverse Mode)
        this->Write(Control1, freq << 0x7);
      case 1:                                                           //Enable Force Reverse Mode
        this->Write(Control1, ((freq << 0x7) | (0x1 << 0xB)));  //Enable bit 11 (Reverse Mode) with Switching Freq
    }
  }

  //void setForceOperationMode(int op_mode = Default, int device = Device){

 //}

  uint16_t getControl1() {
    return this->Read(Control1);
  }
};
#endif
